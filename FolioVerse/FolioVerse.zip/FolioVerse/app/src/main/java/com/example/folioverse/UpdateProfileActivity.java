package com.example.folioverse;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.*;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class UpdateProfileActivity extends AppCompatActivity {

    EditText etEmail, etName, etDob;
    RadioGroup rgGender;
    RadioButton rbMale, rbFemale, rbOther;
    Button btnSaveChanges, btnBack;
    TextView tvEdit;

    // NEW VIEWS
    TextView avatarText, fullNameText, usernameText;

    FirebaseAuth auth;
    FirebaseUser user;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);

        // Link views
        etEmail = findViewById(R.id.etEmail);
        etName = findViewById(R.id.etName);
        etDob = findViewById(R.id.etDob);
        rgGender = findViewById(R.id.rgGender);
        rbMale = findViewById(R.id.rbMale);
        rbFemale = findViewById(R.id.rbFemale);
        rbOther = findViewById(R.id.rbOther);
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        btnBack = findViewById(R.id.btnBack);
        tvEdit = findViewById(R.id.tvEdit);

        // NEW: Avatar and name display
        avatarText = findViewById(R.id.avatarText);
        fullNameText = findViewById(R.id.fullNameText);
        usernameText = findViewById(R.id.usernameText);

        // Firebase
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        user = auth.getCurrentUser();

        if (user == null) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        disableEditing(); // Make fields non-editable initially
        loadUserData();

        // Edit click triggers password check
        tvEdit.setOnClickListener(v -> showPasswordDialog());

        // Save changes
        btnSaveChanges.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String birthday = etDob.getText().toString().trim();
            int selectedId = rgGender.getCheckedRadioButtonId();

            String gender = null;
            if (selectedId == R.id.rbMale) gender = "Male";
            else if (selectedId == R.id.rbFemale) gender = "Female";
            else if (selectedId == R.id.rbOther) gender = "Other";

            if (name.isEmpty() || gender == null) {
                Toast.makeText(this, "Name and gender are required", Toast.LENGTH_SHORT).show();
                return;
            }

            Map<String, Object> updatedData = new HashMap<>();
            updatedData.put("username", name);
            updatedData.put("birthday", birthday);
            updatedData.put("gender", gender);

            db.collection("users").document(user.getUid())
                    .update(updatedData)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Profile updated successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, UserProfileActivity.class));
                        finish();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    });
        });

        btnBack.setOnClickListener(v -> finish());
    }

    private void loadUserData() {
        String uid = user.getUid();
        db.collection("users").document(uid).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String email = documentSnapshot.getString("email");
                        String name = documentSnapshot.getString("username");
                        String birthday = documentSnapshot.getString("birthday");
                        String gender = documentSnapshot.getString("gender");

                        // Set avatar and name info
                        if (email != null) {
                            etEmail.setText(email);
                            usernameText.setText("@" + email.split("@")[0]);

                            if (email.length() > 0) {
                                String firstLetter = String.valueOf(email.charAt(0)).toUpperCase();
                                avatarText.setText(firstLetter);
                            }
                        }

                        if (name != null) {
                            etName.setText(name);
                            fullNameText.setText(name);
                        }

                        if (birthday != null) etDob.setText(birthday);
                        if (gender != null) {
                            switch (gender) {
                                case "Male":
                                    rbMale.setChecked(true);
                                    break;
                                case "Female":
                                    rbFemale.setChecked(true);
                                    break;
                                case "Other":
                                    rbOther.setChecked(true);
                                    break;
                            }
                        }
                    } else {
                        Toast.makeText(this, "User data not found", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to load data: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    private void showPasswordDialog() {
        EditText etPassword = new EditText(this);
        etPassword.setHint("Password");
        etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        new AlertDialog.Builder(this)
                .setTitle("Verify Identity")
                .setMessage("Enter your password to edit profile")
                .setView(etPassword)
                .setPositiveButton("Verify", (dialog, which) -> {
                    String password = etPassword.getText().toString().trim();
                    if (!password.isEmpty()) {
                        reauthenticate(password);
                    } else {
                        Toast.makeText(this, "Password required", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void reauthenticate(String password) {
        AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), password);
        user.reauthenticate(credential)
                .addOnSuccessListener(unused -> {
                    enableEditing();
                    Toast.makeText(this, "You can now edit your profile", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Authentication failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void disableEditing() {
        etEmail.setEnabled(false); // not editable
        etName.setEnabled(false);
        etDob.setEnabled(false);
        rbMale.setEnabled(false);
        rbFemale.setEnabled(false);
        rbOther.setEnabled(false);
        btnSaveChanges.setEnabled(false);
    }

    private void enableEditing() {
        etName.setEnabled(true);
        etDob.setEnabled(true);
        rbMale.setEnabled(true);
        rbFemale.setEnabled(true);
        rbOther.setEnabled(true);
        btnSaveChanges.setEnabled(true);
    }
}

