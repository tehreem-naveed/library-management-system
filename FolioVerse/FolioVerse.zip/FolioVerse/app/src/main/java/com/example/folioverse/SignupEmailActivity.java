package com.example.folioverse;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignupEmailActivity extends AppCompatActivity {

    private EditText emailInput;
    private Button createAccountButton, backButton;
    private FirebaseAuth auth;
    private String selectedRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_email);

        emailInput = findViewById(R.id.signup_email);
        createAccountButton = findViewById(R.id.signup_create_account);
        backButton = findViewById(R.id.btnBack);
        TextView roleDisplay = findViewById(R.id.signup_role_display);

        auth = FirebaseAuth.getInstance();

        selectedRole = getIntent().getStringExtra("ROLE");
        roleDisplay.setText(selectedRole != null ? "Signing up as: " + selectedRole : "Signing up");

        createAccountButton.setOnClickListener(v -> createAccount());
        backButton.setOnClickListener(v -> finish());
    }

    private void createAccount() {
        String email = emailInput.getText().toString().trim();

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInput.setError("Please enter a valid email");
            return;
        }

        // You must define a default password since Firebase requires one
        String defaultPassword = "Default123"; // Or prompt user on next screen

        auth.createUserWithEmailAndPassword(email, defaultPassword)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser firebaseUser = auth.getCurrentUser();
                        if (firebaseUser != null) {
                            Intent intent = new Intent(SignupEmailActivity.this, SetPasswordActivity.class);
                            intent.putExtra("ROLE", selectedRole);
                            startActivity(intent);
                            finish();
                        }
                    } else {
                        Toast.makeText(this, "Signup failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }
}

