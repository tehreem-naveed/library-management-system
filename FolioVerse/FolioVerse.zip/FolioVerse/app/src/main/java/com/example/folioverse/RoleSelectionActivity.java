package com.example.folioverse;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class RoleSelectionActivity extends AppCompatActivity {

    private Button btnUser, btnAdmin;
    private FirebaseFirestore db;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_role_selection);

        btnUser = findViewById(R.id.user_button);
        btnAdmin = findViewById(R.id.admin_button);

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        btnUser.setOnClickListener(v -> saveRoleAndProceed("user"));
        btnAdmin.setOnClickListener(v -> saveRoleAndProceed("admin"));

    }

    private void saveRoleAndProceed(String role) {
        // For new user, we don't have UID yet, so store role locally or in shared prefs
        // Alternatively, if you want to store role before signup, you can keep it in Intent extra
        // Here, let's pass role via Intent to SignupActivity

        Intent intent = new Intent(RoleSelectionActivity.this, UserInfoActivity.class);
        intent.putExtra("ROLE", role);
        startActivity(intent);
        finish(); // prevent going back to role selection from signup
    }
}
