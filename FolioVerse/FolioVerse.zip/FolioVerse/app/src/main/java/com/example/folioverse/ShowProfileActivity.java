package com.example.folioverse;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class ShowProfileActivity extends AppCompatActivity {

    private TextView avatarText, fullNameText, usernameText;
    private Button back_button;

    private FirebaseAuth auth;
    private FirebaseUser user;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_profile);

        // Initialize views
        avatarText = findViewById(R.id.avatarText);
        fullNameText = findViewById(R.id.fullNameText);
        usernameText = findViewById(R.id.usernameText);
        back_button = findViewById(R.id.back_button);


        // Firebase setup
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        db = FirebaseFirestore.getInstance();

        if (user != null) {
            loadUserInfo();
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadUserInfo() {
        db.collection("users").document(user.getUid()).get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        String email = snapshot.getString("email");
                        String name = snapshot.getString("username");

                        if (email != null) {
                            usernameText.setText("@" + email.split("@")[0]);
                            if (!email.isEmpty()) {
                                avatarText.setText(String.valueOf(email.charAt(0)).toUpperCase());
                            }
                        }

                        if (name != null) {
                            fullNameText.setText(name);
                        }
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to load profile info", Toast.LENGTH_SHORT).show()
                );
        back_button.setOnClickListener(v -> finish());

    }
}
